const navMenu=document.getElementById("nav-menu");
const navToggle=document.getElementById("nav-toggle");
const navClose=document.getElementById("nav-close");

navToggle?.addEventListener("click",()=>navMenu.classList.add("show-menu"));
navClose?.addEventListener("click",()=>navMenu.classList.remove("show-menu"));
document.querySelectorAll(".nav__link,.nav__contact").forEach(link=>{
  link.addEventListener("click",()=>navMenu.classList.remove("show-menu"));
});

const header=document.getElementById("header");
const sections=[...document.querySelectorAll("section[id]")];
function updateHeader(){
  header.classList.toggle("scrolled",window.scrollY>30);
  const y=window.scrollY+180;
  sections.forEach(section=>{
    const link=document.querySelector(`.nav__link[href="#${section.id}"]`);
    if(!link)return;
    link.classList.toggle("active-link",y>=section.offsetTop && y<section.offsetTop+section.offsetHeight);
  });
}
window.addEventListener("scroll",updateHeader,{passive:true});
updateHeader();

const typedEl=document.getElementById("home-typed");
const words=["Network Engineer","FTTH Field Engineer","Fiber Optic Technician","Technical Support"];
let wi=0,ci=0,deleting=false;
function typeLoop(){
  const word=words[wi];
  typedEl.textContent=word.slice(0,ci);
  if(!deleting){
    ci++;
    if(ci>word.length){deleting=true;setTimeout(typeLoop,1200);return}
  }else{
    ci--;
    if(ci<0){deleting=false;wi=(wi+1)%words.length;ci=0}
  }
  setTimeout(typeLoop,deleting?45:75);
}
typeLoop();

const observer=new IntersectionObserver(entries=>{
  entries.forEach(entry=>{
    if(entry.isIntersecting)entry.target.classList.add("show");
  });
},{threshold:.12});
document.querySelectorAll(".reveal").forEach(el=>observer.observe(el));

document.getElementById("year").textContent=new Date().getFullYear();
