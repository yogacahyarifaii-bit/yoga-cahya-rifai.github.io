# Yoga Cahya Rifai — Portfolio Website

Website portfolio responsive yang diadaptasi dari template `responsive-porfolio-website-Bianca`.

## Struktur
- `index.html` — halaman utama
- `assets/css/styles.css` — desain dan responsive layout
- `assets/js/main.js` — mobile menu, typing effect, active navigation, reveal animation

## Cara menjalankan
Buka `index.html` di browser. Tidak membutuhkan build system.

## Catatan
- Tema dibuat dark + electric blue agar cocok dengan profil networking/fiber optic.
- Konten disesuaikan dengan data CV Yoga Cahya Rifai.
- Kontak WhatsApp menggunakan format `wa.me`.
