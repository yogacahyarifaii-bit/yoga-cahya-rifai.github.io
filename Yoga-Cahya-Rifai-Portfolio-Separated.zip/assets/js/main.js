/* ==================== MOBILE MENU ==================== */
    const navMenu = document.getElementById('nav-menu');
    const navToggle = document.getElementById('nav-toggle');
    const navClose = document.getElementById('nav-close');

    if (navToggle) {
      navToggle.addEventListener('click', () => {
        navMenu.classList.add('show-menu');
      });
    }

    if (navClose) {
      navClose.addEventListener('click', () => {
        navMenu.classList.remove('show-menu');
      });
    }

    document.querySelectorAll('.nav__link, .nav__contact').forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('show-menu');
      });
    });

    /* ==================== HEADER ON SCROLL ==================== */
    const header = document.getElementById('header');

    function updateHeader() {
      header.classList.toggle('scrolled', window.scrollY > 30);
    }

    window.addEventListener('scroll', updateHeader);
    updateHeader();

    /* ==================== ACTIVE NAV ==================== */
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav__link');

    function updateActiveLink() {
      const scrollY = window.scrollY + 160;

      sections.forEach(section => {
        const top = section.offsetTop;
        const height = section.offsetHeight;
        const id = section.getAttribute('id');

        if (scrollY >= top && scrollY < top + height) {
          navLinks.forEach(link => link.classList.remove('active-link'));
          const active = document.querySelector('.nav__link[href="#' + id + '"]');
          if (active) active.classList.add('active-link');
        }
      });
    }

    window.addEventListener('scroll', updateActiveLink);

    /* ==================== TYPED TEXT ==================== */
    if (window.Typed) {
      new Typed('#typed', {
        strings: [
          'IT &amp; Technical Support',
          'Networking &amp; Fiber Optic',
          'FTTH Field Engineer',
          'Frontend Developer'
        ],
        typeSpeed: 48,
        backSpeed: 28,
        backDelay: 1700,
        loop: true,
        smartBackspace: true
      });
    }

    /* ==================== SCROLL REVEAL ==================== */
    if (window.ScrollReveal) {
      ScrollReveal().reveal('.eyebrow, .section__title, .section__subtitle', {
        distance: '30px',
        origin: 'bottom',
        duration: 800,
        interval: 80,
        reset: false
      });

      ScrollReveal().reveal('.glass-card, .home__content, .home__photo', {
        distance: '45px',
        origin: 'bottom',
        duration: 900,
        interval: 100,
        reset: false
      });
    }

    /* ==================== SCROLL TOP ==================== */
    const scrollTop = document.getElementById('scroll-top');

    window.addEventListener('scroll', () => {
      scrollTop.classList.toggle('show', window.scrollY > 500);
    });

    scrollTop.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    /* ==================== FOOTER YEAR ==================== */
    document.getElementById('year').textContent = new Date().getFullYear();
