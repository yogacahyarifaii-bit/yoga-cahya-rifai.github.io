const root=document.documentElement,theme=document.getElementById('theme'),menu=document.getElementById('menu'),nav=document.getElementById('nav');
const saved=localStorage.getItem('theme'); if(saved) root.dataset.theme=saved;
theme.onclick=()=>{const light=root.dataset.theme==='light';root.dataset.theme=light?'dark':'light';localStorage.setItem('theme',root.dataset.theme);theme.textContent=light?'☼':'☾'};
menu.onclick=()=>{nav.classList.toggle('open');menu.textContent=nav.classList.contains('open')?'×':'☰'};
document.querySelectorAll('nav a').forEach(a=>a.onclick=()=>{nav.classList.remove('open');menu.textContent='☰'});
window.onscroll=()=>{const p=document.documentElement;document.getElementById('progress').style.width=(scrollY/(p.scrollHeight-innerHeight)*100)+'%'};
new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible')}}),{threshold:.12}).observe(document.querySelector('.reveal'));
document.querySelectorAll('.reveal').forEach(e=>new IntersectionObserver(es=>es.forEach(x=>x.isIntersecting&&x.target.classList.add('visible')),{threshold:.12}).observe(e));
document.getElementById('year').textContent=new Date().getFullYear();